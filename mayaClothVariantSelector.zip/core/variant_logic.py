logicDict = {
    "variantDisplay_eyebrows": ["defVariant"], 
    "variantDisplay_eyelashes": ["defVariant"], 
    "variantDisplay_upperCloth": ["empty", "dingoShirt", "tankTopA", "tankTopB", "jumperA", "jumperB", "longSleeveA"], 
    "variantDisplay_lowerCloth": ["empty", "velvetPants", "dungareesA", "trousersA", "trousersB", "shortsA", "shortsB", "jortsA"], 
    "variantDisplay_socks": ["empty", "socksA", "socksB"], 
    "variantDisplay_earringsFirst": ["empty", "earringsA", "earringsB", "earringsC"], 
    "variantDisplay_earringsSecond": ["empty", "studA", "hoopsA"], 
    "variantDisplay_earringsThird": ["empty", "studB", "hoopsB"], 
    "variantDisplay_conchA": ["empty", "conchA"], 
    "variantDisplay_conchB": ["empty", "conchB"], 
    "variantDisplay_necklace": ["empty", "chokerA", "necklaceA"],
    "variantDisplay_hairband": ["empty", "hairbandA"],
    "variantDisplay_ringA": ["empty", "ringA"],
    "variantDisplay_ringB": ["empty", "ringB"]
}
