import sys
import os
import importlib
import codecs

# 💾 Hardcoded paths (update as needed)
tool_path = r"C:/Users/julien.miternique/Documents/workspace/mayaClothVariantSelector"
core_path = os.path.join(tool_path, "core")
json_path = os.path.join(tool_path, "data", "cloth_by_shot.json")
run_path = os.path.join(tool_path, "run.py")

# Add to sys.path
for path in [tool_path, core_path]:
    if path not in sys.path:
        sys.path.append(path)

# Flat imports
import maya_utils
import variant_logic


# Reload modules
importlib.reload(maya_utils)
importlib.reload(variant_logic)

# Set up fake globals and run the logic
import maya.cmds as cmds

charaGloLo = [
    x for x in cmds.ls()
    if ("M_globalLocal_setup_CON" in x or "M_golbalLocal_setup_CON" in x) and
    ("constance" in x or "romane" in x) and
    not x.endswith("Shape")
]
def extract_shot_code(scene_name):
    import re
    match = re.search(r'SQ\d{4}_SH\d{4}', scene_name)
    return match.group(0) if match else None

def get_cloth_variants_for_current_shot(json_path):
    scene_path = cmds.file(q=True, sn=True)
    scene_name = os.path.basename(scene_path)
    shot_code = extract_shot_code(scene_name)

    if not shot_code:
        print("❌ Could not extract Shot code from scene name.")
        return {}

    with open(json_path, 'r', encoding='utf-8') as f:
        cloth_dict = json.load(f)

    if shot_code not in cloth_dict:
        print(f"❌ Shot '{shot_code}' not found in cloth variant data.")
        return {}

    print(f"✅ Using cloth variants from JSON for shot: {shot_code}")
    return cloth_dict[shot_code]

import json
grouped_assets = get_cloth_variants_for_current_shot(json_path)
maya_utils.apply_assets_to_characters(grouped_assets, charaGloLo, variant_logic.logicDict)
